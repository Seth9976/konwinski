from kprize.collection.configs.repo_config import RepoConfig, Spec
